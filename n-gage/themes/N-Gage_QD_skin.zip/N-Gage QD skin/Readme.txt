--------------------------------------------------------------------------------

Author: Cacoman
Copyright (c) 2008

================================================================================
   N-Gage Skin    v. 1.7
================================================================================

This is a skin for n-gage qd and classic n-gage.
 icons are taken from new n-series symbian phones



============
Installation
============


1) transfer and install "N-Series Skin by Cacoman.sis" on your n-gage.


2) restart the phone


3) in the rar archive there are also some wallpapers for the "fake" active desktop effect  


4) to hide the operator logo set the file "white operator logo.jpg" as operator logo whith fexplorer













by Cacoman (c)2008
--------------------------------------------------------------------------------
