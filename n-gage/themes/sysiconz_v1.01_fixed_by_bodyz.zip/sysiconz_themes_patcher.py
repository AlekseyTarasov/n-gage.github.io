﻿'''

Патчер "тем" для исправленной версии SysIconz v1.01 в которой нормально заменяется RealPlayer, Диктофон и Приложения. 
Если установить стороннюю тему на фиксенную версию, то эти три приложению будуть иметь пазл вместо иконки и выдвать ошибку при запуске.
Для того что бы уже готовые "темы" правильно работали с исправленным SysIconz и написан этот скрипт (нужен Python версии 2.7.х для ПК).
Просто запускаем его в папке самой темы (рядом с папками Freak*) и всё, тема готова к использованию.

'''

import os, shutil, struct

def sysiconz_theme_patcher(aDir):

    avoicerec = aDir+"FreakVoiceRec/FreakVoiceRec.aif"
    amidpui = aDir+"FreakMidpUi/FreakMidpUi.aif"
    arealplayer = aDir+"FreakRealPlayer/FreakRealPlayer.aif"
	
	
	
    voicerec = open(avoicerec, 'rb+')
    data = voicerec.read()
    voicerec.seek(0)
    data = data.replace('\x37\x00\x00\x10\x38\x3A\x00\x10\xFC\x03\x04\x01\xCF\x58\x09\x46','\x37\x00\x00\x10\x38\x3A\x00\x10\xCA\x58\x00\x10\x78\xB7\x5C\x96')
    voicerec.write(data)
    voicerec.close()
	
    midpui = open(amidpui, 'rb+')
    data = midpui.read()
    midpui.seek(0)
    data = data.replace('\x37\x00\x00\x10\x38\x3A\x00\x10\xFF\x03\x04\x01\x9C\x0D\x09\x46','\x37\x00\x00\x10\x38\x3A\x00\x10\xC1\x09\x00\x10\x82\x6B\xD2\xAB')
    midpui.write(data)
    midpui.close()
	
	
    realplayer = open(arealplayer, 'rb+')
    data = realplayer.read()
    realplayer.seek(0)
    data = data.replace('\x37\x00\x00\x10\x38\x3A\x00\x10\xFE\x03\x04\x01\xAD\x3E\x09\x46','\x37\x00\x00\x10\x38\x3A\x00\x10\x06\x9D\x00\x10\x41\xE4\xFD\x7F')
    realplayer.write(data)
    realplayer.close()
	

sysiconz_theme_patcher("./")
