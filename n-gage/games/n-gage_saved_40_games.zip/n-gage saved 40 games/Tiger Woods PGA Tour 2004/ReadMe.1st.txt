Tiger Woods PGA Tour 2004 Complete Save Game
===============================================
_______________________________________________
Release Notes:
~~~~~~~~~~~~~~
This save game lets you to unlock everything in career 
mode, including players and courses.
_______________________________________________
Install Notes:
~~~~~~~~~~~~~~
To install the complete save, use explorer apps like
FileMan,  eFileMan,  Fexplorer, SeleQ, etc.
just copy  the 6RAT dir to "C:\System\Apps"
and thats all.

_______________________________________________

Enjoy!
      AzN_dude and ownpda
             Symbianz

Special Thanks to [I]shTuS

�����(-� www.symbianz.net �-)�����