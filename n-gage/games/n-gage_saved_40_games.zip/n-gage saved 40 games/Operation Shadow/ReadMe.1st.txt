hi to all this save game let you to unlock all levels in the Operation Shadow game!
to unlock all levels use explorer apps like FileMan, eFileman, Fexplorer, SeleQ, ... just copy the 6R22 dir to "C:\System\Apps" and thats all!

Enjoy
Symbianz

www.symbianz.net