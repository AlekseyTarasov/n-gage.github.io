Spiderman 2 Complete Save Game
===============================================
_______________________________________________
Release Notes:
~~~~~~~~~~~~~~
This save game lets you to have story mode completed and all secrets unlocked.
_______________________________________________
Install Notes:
~~~~~~~~~~~~~~
To install the complete save, use explorer apps like
FileMan,  eFileMan,  Fexplorer, SeleQ, etc.
just copy  the 6R43 dir to "C:\System\Apps"
and thats all.

_______________________________________________

Enjoy!
      AzN_dude and ownpda
             Symbianz

Special Thanks to [I]shTuS

�����(-� www.symbianz.net �-)�����