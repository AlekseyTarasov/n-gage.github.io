Tom Clancy's Ghost Recon Jungle Storm Save Game
===============================================
_______________________________________________
Release Notes:
~~~~~~~~~~~~~~
This save game let you to  unlock all missions,
challenges and cheats in the Tom Clancy's Ghost
Recon Jungle Storm game.
_______________________________________________
Install Notes:
~~~~~~~~~~~~~~
To unlock all levels use explorer apps like
FileMan,  eFileMan,  Fexplorer, SeleQ, etc.
just copy  the 6RAT dir to "C:\System\Apps"
and thats all.

_______________________________________________

Enjoy!
      mihi_dj
             Symbianz



�����(-� www.symbianz.net �-)�����