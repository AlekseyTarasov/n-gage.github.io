QUAKE I PORT for Nokia Series 60 1st and 2nd edition 
                   PREALPHA 0.06
    (SOFTWARE DISTRIBUTED WITH GNU PUBLIC LICENSE)       

WHATS NEWS (from prealpha 0.51)
+Console background image drawing fixed
+High quality image rendering

WHATS NEWS (from prealpha 0.05)
+crosshair "1" command in autoexec.cfg fixed
+cmdline.cfg  command +map <mapname> added
+water warp and r_waterwarp "1" command in 
   autoexec.cfg (game craches in water) fixed
+r_maxparticles command in autoexec.cfg	added
+Bad status bar gamma after respawning from lava fuxed
+Status bar height fixed
+If I'll try to swap applications, Quake is always at top (fixed) 
+I see-when weapon is turned on it moves like its been heldby drunken (fixed)

 
WHATS NEWS (from prealpha 0.03):

+Game speed acceleration 
+Bugs fixed (crosshair,mods support)
+Bug saving/loading game on strange phone fixed
+Released normal menu and status bar
+Additional string 2D drawing fixed
-Unavailable to fix bug with gamma adjustment from menu (phone hangs)
+Fixed bug with screen size change from menu


INSTALLATION INSTRUCTIONS:

1.  Unzip archive.

2.  If your phone device support only 4K colors copy quakes60.exe from 
   4KCOLORS folder to your phone memory card (with Nokia PC Suite),
   overwise use quakes60.exe from 64KCOLORS folder.     
   
3.  Install your copy of Quake I pak files into the folder id1
   of your memory card. 
   e.t.c.
   memory_card:/id1/pak0.pak 
   (You need the original quake I cd-rom) or download
   quake I pak0.pak from ID Sofrware (shareware quake I)

4.  Copy file autoexec.cfg into folder id1 of your memory card
   (This file contains some adjustments of game speed without 
    lost quality and keys definitions).
   e.t.c.
   memory_card:/id1/autoexec.cfg  
   Don't forget to delete file config.cfg in same folder !!!   

5. Launch any file manager software on your phone.

6. Find quakes60.exe on root folder of your memory card 
   (phone drive e:)

7. Chose File->Open in your FileManager and run game.

8. If your file manager software support command line options
   you can add additional options to game. If not read next 
   section.   

9. Enjoy !

HOW TO WRITE cmdline.cfg FILE:

1 Create empty cmdline.cfg file in id1 folder of your phone 
  memory card.

2 Write in text editor in one line with space delimiters 
  your command line options.

3 Save file

4 Run game with mods support and enjoy !

HOW TO USE MODS WITH QUAKES60

1. Copy your mod folder to root of your phone memory card

2. Write cmdline.cfg file in id1 folder located on root of your 
   phone memory card with single line:
-game mod_folder_name
   where mod_folder_name is name of folder your mod

3. Run game with mods support and enjoy !
    

DEFAULT CONTROLS WRITTEN IN AUTOEXEC.CFG:


Left,Right,Up,Down keys: 
            Move and Rotate

Enter: 
            Jump        

Left func: 
            fire

Numeric keypad:
	1 - next weapon 
	2 - look up 
	3 - nothing 
	4 - strafe left 
	5 - fire 
	6 - strafe right 
	7 - jump 
	8 - look down 
	9 - swim down 
	0 - all weapons/keys 
	* - menu 
	# - god mode 

 


TESTED WITH SMARTPHONES:
 
   SIEMENS SX1 (NGAGE PATCH)
   NOKIA 6600,N-Gage,N-Gage QD, 6630, 6670, 6680, 6681, N70


LAUNCHED WITH:
 
    Handy File 
    ProfyExplorer
    FExplorer
    Griffon 


BUGS, REPORTS, COMMENTS:

  You may post on http://sourceforge.net/projects/quakes60 

ATTENTION: THIS SOFTWARE COMES WITHOUT ANY KIND OF GUARANTIE, 
           USE THIS SOFTWARE ON YOUR OWN RISK !!! 
           SEE LICENSE.TXT FOR PROPER INFORMATION.


(c) 2006 Dmitry Gazko (dgazko@big,spb,ru)
(c) 2006 Dr.Khumen Research Labs Ltd. (http://quakes60.sourceforge.net)
Shareware Quake I packs and quake I source code (c) Id Software
