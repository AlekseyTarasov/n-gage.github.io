=======================================================
=Tomb Raider Loader (TRLoader) for Nokia N-Gage v0.11=
=======================================================

It was discovered that the Tomb Raider game build for the Nokia N-Gage uses a re-texturing file (located on the original MMC at System\Apps\tombraider\Data\DELDATA\retexture.dat) to apply a patch at start-up which changes Lara's classic outfit present on the PlayStation/PC/Pocket PC games to the Angel of Darkness variant, exclusive to the N-Gage platform for this title. The classic outfit is still available within the game files and is loaded if the retexture.dat file is missing at launch. The easiest way to achieve the change is to delete the file, but that solution would prevent going back to the default outfit. This loader was created to solve that issue.

*because of how EKA2L1 mounts a virtual MMC game card (as read-only), this application is incompatible with the current version of the N-Gage emulator and can only be used on original Nokia hardware. A potential workaround would be to manually copy all the game files to virtual drive E:\

================
=How To Install=
================

Transfer a copy of Tomb Raider Starring Lara Croft to the root of the MMC.
Go to: System\Apps\tombraider\ and rename the file tombraider.app to tombraider.dll
Copy/Paste the TRLoader folder from this archive to System\Apps\


Hardware layout:

E:\System\Apps\TRLoader\
    TRLoader.app
    TRLoader.rsc
    TRLoader_caption.rsc
    TRLoader.aif
    background.mbm
    background_music.wav

E:\System\Apps\tombraider\
    tombraider.dll
    [all other original game files]
    data\deldata\retexture.dat OR retexture.dat.bak


===========
=Changelog=
===========

v0.11
=====
Added background music at System\Apps\TRLoader\background_music.wav (keygen music FTW!!)
Changed to a smaller S60 DenseFont and centered the text for a cleaner UI experience.

v0.10b
======
Implemented a custom background for the loader. To use your own artwork, replace the file background.mbm present in System\Apps\TRLoader\
Added an "About" section.
Added the current build number to the title screen.
Implemented 5/7 select/back/exit key functions in the menus.

v0.10
=====
Fixed the duplicate menu icons by renaming the original tombraider.app to .dll and changing the loader's behaviour.

v0.7
====
The loader runs the game as intended.
TRLoader menu icon alongside original Tomb Raider one. Not ideal.

v0.6
====
The loader displays a menu, but does not run the game because of the modified game path.

v0.1
====
First build.
System Error.
Nothing works, lol :)

==============
=Known Issues=
==============

Released 23 years too late. sorry :(

=========
=Credits=
=========

This is AI slop :P

===========
=Greetings=
===========

To everyone keeping the Nokia N-Gage alive, mupf.dev & Vanessa Summers!

=========
=Contact=
=========

Visit the official Nokia N-Gage Discord at https://discord.gg/wm7bYRErfZ