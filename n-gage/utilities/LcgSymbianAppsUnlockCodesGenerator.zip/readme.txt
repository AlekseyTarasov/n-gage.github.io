This is official unlock code generator, that we used in LCG for creating unlock codes for customers of our Symbian apps who needed support (due to changed devices, or other reason).

In past years, most of our Symbian apps were transformed to freeware, but not all of them, the oldest ones were excluded.

This tool allows to generate unlock code, and use these apps on historic Symbian phones.

There are two forms of code: numeric that you enter in app's register screen, or binary that you install on phone, and app will trust the binary key and won't invoke online check. 

Enjoy...
Lonely Cat Games
